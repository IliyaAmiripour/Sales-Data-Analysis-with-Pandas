import pandas as pd

def load_data(path):
    df = pd.read_csv(path)
    return df
def clean_data(df):
    df = df.drop_duplicates()
    df = df.dropna()
    df["Date"] = pd.to_datetime(df["Date"])
    df["Total"] = df["Price"] * df["Quantity"]
    return df
