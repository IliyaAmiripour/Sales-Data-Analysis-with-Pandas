import os
def generate_reports(df):
    os.makedirs("output", exist_ok = True)
    total_sales = df["Total"].sum()
    avg_sales = df["Total"].mean()
    top_products = (df.groupby("Product")["Quantity"].sum().sort_values(ascending = False))
    city_sales = df.groupby("City")["Total"].sum()
    monthly_sales = df.groupby(df["Date"].dt.to_period("M"))["Total"].sum()
    df.to_cvs("output/cleaned_sales.cvs", index=False)
    top_products.to_cvs("output/top_products.cvs")
    city_sales.to_cvs("output/city_sales.cvs")
    monthly_sales.to_cvs("output/monthly_sales.cvs")
    
    with open("output/report.txt", "w") as f: f.write("SALES REPORT\n")
    f.write("=============================\n")
    f.write(f"Total Sales:{total_sales}\n")
    f.write(f"Averange Sales:{avg_sales:.2f}\n")
        
                                                      