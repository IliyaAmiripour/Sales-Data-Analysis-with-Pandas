import os
import matplotlib.pyplot as plt


def create_charts(df):
    os.makedirs("output/charts", exist_ok=True)

    
    monthly_sales = df.groupby(df["Date"].dt.to_period("M"))["Total"].sum()

    plt.figure()
    monthly_sales.plot(kind="bar")
    plt.title("Monthly Sales")
    plt.xlabel("Month")
    plt.ylabel("Revenue")
    plt.tight_layout()
    plt.savefig("output/charts/monthly_sales.png")
    plt.close()

    
    top_products = df.groupby("Product")["Quantity"].sum()

    plt.figure()
    top_products.plot(kind="bar")
    plt.title("Top Products")
    plt.xlabel("Product")
    plt.ylabel("Quantity Sold")
    plt.tight_layout()
    plt.savefig("output/charts/top_products.png")
    plt.close()