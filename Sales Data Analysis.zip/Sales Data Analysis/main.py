from src.clean import load_data, clean_data
from src.analysis import generate_reports
from src.charts import create_charts


def main():
    df = load_data("data/sales.csv")
    df = clean_data(df)

    generate_reports(df)
    create_charts(df)

    print("✅ Analysis completed successfully!")


if __name__ == "main":
    main()